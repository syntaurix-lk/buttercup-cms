"""
Buttercup Home Page CMS Backend Application

This package contains the FastAPI application for managing
home page content for the Buttercup restaurant website.
"""

__version__ = "1.0.0"
